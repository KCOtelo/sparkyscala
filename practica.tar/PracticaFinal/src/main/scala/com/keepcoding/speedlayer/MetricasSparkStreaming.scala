package com.keepcoding.speedlayer

import java.sql.Date
import java.text.SimpleDateFormat
import java.util.Properties

import com.keepcoding.MetricasSql
import com.keepcoding.dominio.{Cliente, Geolocalizacion, Transaccion}
import com.keepcoding.speedlayer.producer.{ApplicationConfig, ClienteKProducer, StringKProducer, TransaccionKProducer}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.util.LongAccumulator
import org.joda.time.DateTime

import scala.util.{Failure, Success, Try}
//import org.apache.kafka.common.serialization.StringDeserializer

import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.{Seconds, StreamingContext}

import scala.xml.Properties

class MetricasSparkStreaming(applicationConf: String) {

  private val AppConf = ApplicationConfig(applicationConf)

  def run(args: Array[String]): Unit = {

    val conf = new SparkConf().setMaster("local[*]").setAppName("Práctica Final - Speed Layer")


    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> s"${AppConf.broker}:${AppConf.port}", //localhost:9092",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "spark-demo",
      "kafka.consumer.id" -> "kafka-consumer-01"
    )

    val ssc = new StreamingContext(conf, Seconds(5))

    ssc.sparkContext.setLogLevel("ERROR")


    // en args(0) debe venir el nombre del topico al que nos vamos a suscribir
    val inputEnBruto: InputDStream[ConsumerRecord[String, String]] = KafkaUtils.createDirectStream(ssc,
      PreferConsistent, Subscribe[String, String](Array(AppConf.topic_consumer), kafkaParams))

    val transaccionesStream: DStream[Array[String]] = inputEnBruto.map(_.value().split(","))

    val DATE_FORMAT = "d/M/yy h:m"
    val dateformat = new SimpleDateFormat(DATE_FORMAT)
   // var dni:Int = 0
    var descripcion:String = ""
    var categoria:String = ""
    val categoriaOcio:List[String] = List("Shopping Mall","Restaurant","Cinema","Sports")
    val acumulador: LongAccumulator = ssc.sparkContext.longAccumulator("dniCliente")

    val streamTransformado = transaccionesStream.map(event => {
      acumulador.add(1)
      val descripcion = event(10).toString.trim
      // Asignamos la categoria segun si es ocio o no
      categoria = if(categoriaOcio.contains(descripcion))  "Ocio" else "others"

      new Tuple2(Cliente(acumulador.value, event(4).toString, event(6).toString),
        Transaccion(acumulador.value, event(2).toDouble, descripcion, categoria, event(3).toString,
          Geolocalizacion(event(8).toDouble, event(9).toDouble, event(5).toString.trim, "N/A"),
          new java.sql.Date(dateformat.parse(event(0).toString.replace("[","").trim).getTime)  ))
    })

    // Por cada transformacion que equivale a una tarea del enunciado enviarlo a un tópico distinto

    // Las metricas 1,2,3,5 las implementamos con RDD's
    metrica1(streamTransformado)
    metrica2(streamTransformado)
    metrica3(streamTransformado)
    metrica5(streamTransformado)

    // Las metricas 4,6 las implemtamos mediante sparkSql
    metricasSQL(streamTransformado)

    // arrancamos spark streaming
    ssc.start()
    ssc.awaitTermination()


  }

  // METRICA 1 Implementada con RDDs: Número de operaciones realizadas por cliente y ciudad
  def metrica1(streamTransformado: DStream[(Cliente,Transaccion)]) {

    val metrica1 = streamTransformado
                    .map(cliente => (cliente._2.geolocalizacion.ciudad, 1))
                    .reduceByKey(_+_)
                    .map(fila => fila._1 +","+fila._2.toString) // transformamos el resultado a un string para mandarlo

    // Otra opcion es agruparla tambien por cliente
    val metrica1_1 = streamTransformado
                    .map(cliente => (cliente._1.nombre+","+cliente._2.geolocalizacion.ciudad, 1))
                    .reduceByKey(_+_)
                    .map(fila => fila._1 +","+fila._2.toString)

    metrica1.print()

    // Mandamos (ciudad,num transacciones) como string
    sendStringToKafka(AppConf.topic_metrica1, metrica1)

  }

  // METRICA 2 Implementada con RDDs: Transacciones por un importe superior a 500
  def metrica2(streamTransformado: DStream[(Cliente,Transaccion)]) {

    val metrica2 = streamTransformado.filter(_._2.importe > 500)
    metrica2.print()

    // La mandamos serializada
    sendMetricToKafka(AppConf.topic_metrica2, metrica2)
  }

  // METRICA 3 Implementada con RDDs: Transacciones agrupadas por cliente cuya ciudad sea X
  def metrica3(streamTransformado: DStream[(Cliente,Transaccion)]): Unit ={

    val x:String = "London"
    val metrica3 = streamTransformado.filter(_._2.geolocalizacion.ciudad == x)
      .map(cliente => (cliente._1.nombre, 1))
      .reduceByKey(_+_)
      .map(fila => fila._1 +","+fila._2.toString) // transformamos el resultado a un string para mandarlo

    metrica3.print()

    sendStringToKafka(AppConf.topic_metrica3, metrica3)
  }


  // METRICA5 Implementada con RDDs: Úlitmas transacciones de cada cliente el los últimos 30 dias
  def metrica5(streamTransformado: DStream[(Cliente,Transaccion)]): Unit = {
    val DATE_FORMAT = "d/M/yy h:m"
    val dateformat = new SimpleDateFormat(DATE_FORMAT)
    val diaDesde: java.sql.Date = new java.sql.Date(dateformat.parse("01/03/09 00:00").getTime)

    val metrica5 = streamTransformado.filter(_._2.fechaTransaccion.compareTo(diaDesde) > 0)

    metrica5.print()
    // La mandamos serializada
    sendMetricToKafka(AppConf.topic_metrica5, metrica5)

  }

  // IMPLEMENTAMOS LAS METRICAS 4 Y 6  MEDIANTE SPARK SQL
  def metricasSQL(streamTransformado: DStream[(Cliente,Transaccion)]): Unit = {

    streamTransformado.foreachRDD { rdd =>
      val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
      import spark.implicits._

      val dfCliente       = rdd.toDS().map(_._1)
      val dfTransacciones = rdd.toDS().map(_._2)

      dfCliente.createOrReplaceGlobalTempView("CLIENTES")
      dfTransacciones.createOrReplaceGlobalTempView("TRANSACCIONES")


      val metrica4 = MetricasSql.metrica4(spark)
      sendDFToKafka(AppConf.topic_metrica4,metrica4)

      val metrica6 = MetricasSql.metricaPropia1(spark)
      sendDFToKafka(AppConf.topic_metrica6,metrica6)

    }
  }

  // Envia un DataFrame al topico "topic" de Kafka
  def sendDFToKafka(topic:String, metrica:DataFrame): Unit = {
    metrica.rdd.foreachPartition{partitionOfRecords =>
      val stringProducer: StringKProducer[String, String] = new StringKProducer[String, String](topic)

      partitionOfRecords.foreach( record =>
        Try(
          stringProducer.produce(topic,"1",record.toString())
        ) match {
          case Success(m) =>
            val metadata = m.get()
            println("Success writing to Kafka topic:" + metadata.topic(),
              metadata.offset(),
              metadata.partition(),
              new DateTime(metadata.timestamp()))
          case Failure(f) =>
            println("Failed writing to Kafka", f.printStackTrace())
            stringProducer.close()
        }
      )
    }
  }

  def sendStringToKafka(topic:String, metric:DStream[String]) {
    metric.foreachRDD(rdd =>
      rdd.foreachPartition { partitionOfRecords =>
        val stringProducer: StringKProducer[String, String] = new StringKProducer[String, String](topic)

        partitionOfRecords.foreach( record =>
          Try(
            stringProducer.produce(topic,"1",record)
          ) match {
            case Success(m) =>
                  val metadata = m.get()
                  println("Success writing to Kafka topic:" + metadata.topic(),
                    metadata.offset(),
                    metadata.partition(),
                    new DateTime(metadata.timestamp()))
            case Failure(f) =>
              println("Failed writing to Kafka", f.printStackTrace())
              stringProducer.close()
          }
        )
      }
    )
  }

  def sendMetricToKafka(topic:String, metric:DStream[(Cliente,Transaccion)]) {
    metric.foreachRDD(rdd =>
      rdd.foreachPartition { partitionOfRecords =>
        val cienteProducer: ClienteKProducer[String, Cliente] = new ClienteKProducer[String, Cliente](topic)
        val transaccionProducer: TransaccionKProducer[String, Transaccion] = new TransaccionKProducer[String, Transaccion](topic)

        partitionOfRecords.foreach( record =>
          Try(
            cienteProducer.produce(topic,"1",record._1)
          ) match {
            case Success(m) =>
              Try(
                transaccionProducer.produce(topic,"1",record._2)
              ) match {
                case Success(m2) =>
                  val metadata = m2.get()
                  println("Success writing to Kafka topic:" + metadata.topic(),
                    metadata.offset(),
                    metadata.partition(),
                    new DateTime(metadata.timestamp())
                  )
                case Failure(f) =>
                  println("Failed writing to Kafka", f.printStackTrace())
                  transaccionProducer.close()
              }
            case Failure(f) =>
              println("Failed writing to Kafka", f.printStackTrace())
              cienteProducer.close()
          }
        )
      }
    )
  }


}

/** Lazily instantiated singleton instance of SparkSession */
object SparkSessionSingleton {

  @transient  private var instance: SparkSession = _

  def getInstance(sparkConf: SparkConf): SparkSession = {
    if (instance == null) {
      instance = SparkSession
        .builder
        .config(sparkConf)
        .getOrCreate()
    }
    instance
  }
}