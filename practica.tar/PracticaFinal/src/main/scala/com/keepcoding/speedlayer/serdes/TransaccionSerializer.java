package com.keepcoding.speedlayer.serdes;


import com.keepcoding.dominio.Transaccion;
import org.apache.kafka.common.serialization.Serializer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;

public class TransaccionSerializer implements Serializer<Transaccion> {
    public void configure(Map<String, ?> configs, boolean isKey){

    }

    public byte[] serialize(String topic, Transaccion obj) {
        byte[] bytes = null;
        ByteArrayOutputStream bos = null;
        ObjectOutputStream oos = null;
        try {
            bos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(bos);
            oos.writeObject(obj);
            oos.flush();
            bytes = bos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bytes;
    }

    public void close(){}
}
