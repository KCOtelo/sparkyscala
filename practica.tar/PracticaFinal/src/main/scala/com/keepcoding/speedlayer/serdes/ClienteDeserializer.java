package com.keepcoding.speedlayer.serdes;

//import com.keepcoding.dominio.Cliente;
import com.keepcoding.dominio.Cliente;
import org.apache.kafka.common.serialization.Deserializer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Map;

public class ClienteDeserializer implements Deserializer<Cliente> {

    public void configure(Map<String, ?> configs, boolean isKey){

    }

    public Cliente deserialize(String topic, byte[] data){
        Object obj = null;
        ByteArrayInputStream bis = null;
        ObjectInputStream ois = null;
        try{
            bis = new ByteArrayInputStream(data);
            ois = new ObjectInputStream(bis);
            obj = ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return (Cliente) obj;

    }
    public void close(){

    }
}
