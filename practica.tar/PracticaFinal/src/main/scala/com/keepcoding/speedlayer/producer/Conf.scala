package com.keepcoding.speedlayer.producer

import java.io.File

import com.typesafe.config.{Config, ConfigFactory}

case class ApplicationConfig(configPath: String) {
  val config: Config = ConfigFactory.parseFile(new File(configPath))
  val broker: String = config.getString("broker")
  val port: Int = config.getInt("port")
  val topic_consumer: String = config.getString("topic_consumer")
  val topic_metrica1: String = config.getString("topic_metrica1")
  val topic_metrica2: String = config.getString("topic_metrica2")
  val topic_metrica3: String = config.getString("topic_metrica3")
  val topic_metrica4: String = config.getString("topic_metrica4")
  val topic_metrica5: String = config.getString("topic_metrica5")
  val topic_metrica6: String = config.getString("topic_metrica6")
  val topic_metrica7: String = config.getString("topic_metrica7")
}
