package com.keepcoding.speedlayer.producer

import java.util.Properties
import java.util.concurrent.Future

import com.keepcoding.dominio.Cliente
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord, RecordMetadata}

class StringKProducer[K <: String, V <: String](topic: String) {
  val kafkaProps = new Properties()
  kafkaProps.put("bootstrap.servers", "localhost:9092")
  kafkaProps.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  kafkaProps.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")

  private lazy val producer = new KafkaProducer[String, String](kafkaProps)

  def produce(topic: String, key: String, value: String, partition: Int = 0) : Future[RecordMetadata] = {
    val record = new ProducerRecord(topic, "1", value)
    producer.send(record)
  }

  def close(): Unit ={
    producer.flush()
    producer.close()
  }
}