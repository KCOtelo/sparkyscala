package com.keepcoding.speedlayer.producer


import java.util.Properties
import java.util.concurrent.Future

import com.keepcoding.dominio.Transaccion
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord, RecordMetadata}

class TransaccionKProducer[K <: String, V <: Transaccion](topic: String) {
  val kafkaProps = new Properties()
  kafkaProps.put("bootstrap.servers", "localhost:9092")
  kafkaProps.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  kafkaProps.put("value.serializer", "com.keepcoding.speedlayer.serdes.TransaccionSerializer")

  private lazy val producer = new KafkaProducer[String, Transaccion](kafkaProps)

  def produce(topic: String, key: String, value: Transaccion, partition: Int = 0) : Future[RecordMetadata] = {
    val record = new ProducerRecord(topic, "1", value)
    producer.send(record)
  }

  def close(): Unit ={
    producer.flush()
    producer.close()
  }
}