package com.keepcoding

import org.apache.spark.sql
import org.apache.spark.sql.SparkSession

object MetricasSql {


  // METRICA 1: Número de operaciones realizadas por cliente y ciudad
  def metrica1(sparkSession: SparkSession): sql.DataFrame ={
    val metrica = sparkSession.sql(
      "SELECT  t.geolocalizacion.ciudad, count(*) AS transacciones" +
               " FROM global_temp.TRANSACCIONES t INNER JOIN global_temp.CLIENTES c ON t.DNI = c.DNI "  +
               " GROUP BY  t.geolocalizacion.ciudad" +
               " ORDER BY 2 DESC")

    printResults("Número de operaciones realizadas por cliente y ciudad",metrica)
    metrica
  }

  // METRICA 2. Clientes que hayan realizado pagos superiores a 500
  def metrica2(sparkSession: SparkSession): sql.DataFrame = {
    val metrica = sparkSession.sql(
      "SELECT c.dni,c.nombre,t.importe" +
               " FROM global_temp.TRANSACCIONES t INNER JOIN global_temp.CLIENTES c ON t.DNI = c.DNI" +
               " WHERE t.importe > 500")

    printResults("Clientes que hayan realizado pagos superiores a 500",metrica)
    metrica
  }


  // METRICA 3. Transacciones agrupadas por cliente cuya ciudad sea "ciudad"
  def metrica3(sparkSession: SparkSession, ciudad:String): sql.DataFrame = {
    val metrica = sparkSession.sql(
      "SELECT c.dni,c.nombre,count(*) AS transacciones" +
               " FROM global_temp.TRANSACCIONES t INNER JOIN global_temp.CLIENTES c ON t.DNI = c.DNI" +
               s" WHERE t.geolocalizacion.ciudad = '$ciudad' " +
               "GROUP BY c.dni,c.nombre ORDER BY 3 DESC")

    printResults("Transacciones agrupadas por cliente cuya ciudad sea "+ciudad,metrica)
    metrica
  }

  // METRICA 4. filtrar todas las operaciones cuya categoria sea Ocio
  def metrica4(sparkSession: SparkSession): sql.DataFrame = {
    // Solución 1.
    val categoriaOcio: List[String] = List("Shopping Mall", "Restaurant", "Cinema", "Sports")
    // la convertimos al string nicesario para ponerlo en la select
    val stringCategoria = categoriaOcio.mkString("('", "','", "')")

    val metrica0 = sparkSession.sql("" +
      "SELECT * FROM global_temp.TRANSACCIONES " +
      s"WHERE descripcion IN $stringCategoria")

    // Solucion 2. Sabemos que ya hemos rellenado el campo categoria de forma correcta al crear el RDD
    val metrica = sparkSession.sql("" +
      "SELECT * FROM global_temp.TRANSACCIONES " +
      "WHERE categoria = 'Ocio'")

    printResults("operaciones cuya categoria sea Ocio",metrica)
    metrica
  }

  // METRICA 5: Transacciones de cada cliente en los últimos 30 dias
  def metrica5(sparkSession: SparkSession): sql.DataFrame = {
    val metrica = sparkSession.sql("" +
    "SELECT c.*,t.importe,t.descripcion,t.categoria,t.tarjetaCredito,t.geolocalizacion,t.fechaTransaccion" +
      " FROM global_temp.TRANSACCIONES t INNER JOIN global_temp.CLIENTES c ON t.DNI = c.DNI" +
      //" GROUP BY upper(c.nombre)" +
      " ORDER BY fechaTransaccion DESC" +
      " LIMIT 30"
    )
    printResults("Transacciones de cada cliente en los últimos 30 dias",metrica)
    metrica
  }

  // METRICA PROPIA 1: Media gastada por categoria y ciudad
  def metricaPropia1(sparkSession: SparkSession): sql.DataFrame ={
    val metrica = sparkSession.sql(
        "select categoria,geolocalizacion.ciudad, avg(importe) as importe_medio " +
                 "from global_temp.TRANSACCIONES " +
                 "group by categoria, geolocalizacion.ciudad")
    printResults("Media gastada por categoria y ciudad",metrica)
    metrica
  }

  def printResults(titulo: String, metrica:sql.DataFrame): Unit ={
    val linea = "~"*(titulo.length+10)
    val lineaTitulo = " "*5 + titulo
    println(linea)
    println(lineaTitulo)
    println(linea)

    metrica.show()
    println("Total registros: " + metrica.count())

    println(linea)

  }


}
