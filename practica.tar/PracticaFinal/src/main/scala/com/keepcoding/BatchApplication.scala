package com.keepcoding

import com.keepcoding.batchlayer.MetricasSparkSQL

object BatchApplication {

  def main(args: Array[String]): Unit = {
    if(args.length == 2){
      MetricasSparkSQL.run(args)

    } else {
      println("Se está intentando arrancar el job de Spark sin los parametros correctos")
      ///home/keepcoding/KeepCoding/Workspace/PracticaFinal/dataset/TransaccionesNew.csv
      ///home/keepcoding/KeepCoding/Workspace/PracticaFinal/datasetOutput
      println("Parámetro 1: fichero de entrada con las transacciones")
      println("Parámetro 2: directorio de salida")
    }
  }

}
