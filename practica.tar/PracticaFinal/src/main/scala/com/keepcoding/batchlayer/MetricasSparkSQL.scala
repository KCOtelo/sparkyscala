package com.keepcoding.batchlayer

import java.text.SimpleDateFormat


import com.keepcoding.MetricasSql
import com.keepcoding.dominio.{Cliente, Geolocalizacion, Transaccion}
import org.apache.spark.sql.SparkSession
import org.apache.spark.util.LongAccumulator

object MetricasSparkSQL {

  def run(args: Array[String]) :Unit ={

    val sparkSession =  SparkSession.builder().master("local[*]")
      .appName("Prácitca final - Batch Layer SparkSQL")
      .getOrCreate()

    sparkSession.sparkContext.setLogLevel("ERROR")

    import sparkSession.implicits._

    val rddTransacciones = sparkSession.read.csv(s"file:///${args(0)}")

    val cabecera = rddTransacciones.first

    val rddSinCabecera = rddTransacciones.filter(!_.equals(cabecera)).map(_.toString().split(","))

    // Acumuladores para generar el DNI
    val acumulador: LongAccumulator = sparkSession.sparkContext.longAccumulator("dniCliente")
    val acumuladorTransaccion: LongAccumulator = sparkSession.sparkContext.longAccumulator("dniTransaccion")

    // Definimos el dataFrame de Clientes
    val dfClientes = rddSinCabecera.map(columna => {
      acumulador.add(1)
      Cliente(acumulador.value, // DNI
              columna(4),       // Nombre
              columna(6))       // Cta. corriente
    })


    // Definimos el dataFrame de Transacciones

    val DATE_FORMAT = "M/d/yy HH:mm"
    val dateformat = new SimpleDateFormat(DATE_FORMAT)
    val categoriaOcio:List[String] = List("Shopping Mall","Restaurant","Cinema","Sports")
    var descripcion : String = ""

    val dfTransacciones = rddSinCabecera.map(columna => {
      acumuladorTransaccion.add(1)

      val descripcion = columna(10).replace("]","").trim
      val categoria = if(categoriaOcio.contains(descripcion))  "Ocio" else "others"
      val fechaTransaccion = new java.sql.Date(dateformat.parse(columna(0)
        .replace("[","").trim)
        .getTime)

      Transaccion(acumuladorTransaccion.value,                                  // DNI cliente
                  columna(2).toDouble,                                          // Importe
                  descripcion,                                                  // Descripción
                  categoria,                                                    // Categoria
                  columna(3),                                                   // Trja. crédito
                  Geolocalizacion(columna(8).toDouble,                          // Latitud
                                  columna(9).toDouble,                          // Longitud
                                  columna(5).trim,                              // Ciudad
                                  "N/A"),                                       // Pais
                                  fechaTransaccion                              // Fecha transacción
      )
    })

    // Creamos las vistas temporales
    dfTransacciones.createGlobalTempView("TRANSACCIONES")
    dfClientes.createGlobalTempView("CLIENTES")

    // Generamos todas las métricas y las almacenamos en ficheros
    val metrica1 = MetricasSql.metrica1(sparkSession)
    // Guardamos la metrica1 en csv
    metrica1.write.csv("file://"+args(1)+"/metrica1.csv")

    val metrica2 = MetricasSql.metrica2(sparkSession)
    // Guardamos la metrica2 en csv
    metrica2.write.csv("file://"+args(1)+"/metrica2.csv")

    val metrica3 = MetricasSql.metrica3(sparkSession,"London")
    // Guardamos la metrica3 en csv
    metrica3.write.csv("file://"+args(1)+"/metrica3.csv")

    val metrica4 = MetricasSql.metrica4(sparkSession)
    // Guardamos la metrica4 en json
    metrica4.write.json("file://"+args(1)+"/metrica4.json")

    val metrica5 = MetricasSql.metrica5(sparkSession)
    // Guardamos la metrica5 en avro
    metrica5.write.format("com.databricks.spark.avro").save("file://"+args(1)+"/metrica5_avro")

    val metrica6 = MetricasSql.metricaPropia1(sparkSession)
    // Guardamos la metrica6 en aparquet
    metrica6.write.parquet("file://"+args(1)+"/metrica6_parquet")




  }

}
